* clone this project
* create a firebase account and download google-services.json
* paste google-services.json under android/app
* enable email/password authentication enabled in firebase account
* after registration you can check the data in the users tab in firebase
* create a firestore database
* create a database collection as products
* add field name and value 
* add field image and value
* then it will reflect in the home page
